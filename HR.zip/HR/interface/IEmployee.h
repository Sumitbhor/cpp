
using namespace std;
#include <string>
#ifndef Employee_cpp
#define Employee_cpp
class IEmployee
{
public:
    int id;
    string firstname;
    string lastname;
    string email;
    double baseSalary;
    string city;
    string phone;
    double HRA;
    double Allowance;
    virtual void doWork() = 0;

    virtual double computePay() = 0;

    virtual string to_String() = 0;
};
#endif