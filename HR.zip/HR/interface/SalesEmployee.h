#include <iostream>
using namespace std;
#include <string>
#include "ISalesEmployee.h"
#include "IAppraisable.h"
#include "IBonusEligible.h"
#ifndef SalesEmployee_h
#define SalesEmployee_h

class SalesEmployee : public ISalesEmployee
                      
{

public:
    
    SalesEmployee()
    {
        this->id = 0;
        this->firstname = "";
        this->lastname = "";
        this->email = "";
        this->phone = "";
        this->city = "";
        this->baseSalary = 0;
        this->HRA = 0;
        this->Allowance = 0;
        this->incentive = 0;
        this->target = 0;
        this->achiveTarget = 0;
    }

    SalesEmployee(int id,
                  string firstname,
                  string lastname,
                  string email,
                  string phone,
                  string city,
                  double baseSalary,
                  double HRA,
                  double Allowance,
                  double incentive,
                  int target,
                  int achiveTarget) : Employee(id, firstname, lastname, email, phone, city, baseSalary, HRA, Allowance)
    {
        this->incentive = incentive;
        this->target = target;
        this->achiveTarget = achiveTarget;
    }
    virtual void doWork() override;

    virtual double computePay() override;
    

    void Conduct_Appraisable() override ;
};
#endif