#ifndef ITrainer_h
#define ITrainer_h
class ITrainer
{
private:
    /* data */
public:
    virtual void Train() = 0;
};
#endif