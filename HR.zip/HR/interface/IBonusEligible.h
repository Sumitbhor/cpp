#ifndef IBONUSELIGIBLE_H
#define IBONUSELIGIBLE_H
class IBonusEligible
{
    /* data */
public:
    virtual float CalculateBonus() = 0;
};

#endif
